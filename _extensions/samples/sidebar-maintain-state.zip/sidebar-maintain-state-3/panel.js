var maintext = document.querySelector("#maintext");
var theValue;


maintext.onchange = function(){
	save();
}

function save(){
	theValue = maintext.value;
	chrome.extension.getBackgroundPage().setValue(theValue);
}

function show(){
	theValue = chrome.extension.getBackgroundPage().getValue();
	
	if (!theValue){
		theValue = "";
	}
	
	maintext.value = theValue;
}

document.addEventListener("DOMContentLoaded", show, false);