$(function() {

	var body = $(document.body);
	var page = $('body>section');

	var beforeFontSize = parseInt(body.css('font-size'));
	var bodyWidthBefore = body.width();
	var bodyHeightBefore = body.height();

	function updateView() {

		if(body.css('background-color') == '#000000') {

			window.scrollTo(0,0);

			var hash = document.location.hash;
				hash = (hash.length && $(hash).length) ? hash : page.attr('id');
			
			document.location.hash = hash;

			var bodyWidthAfter = body.width();
			var bodyHeightAfter = body.height();

			while(page.width() < bodyWidthAfter && page.height() < bodyHeightAfter) {
				body.css('font-size',parseInt(body.css('font-size'))+1);
			}

			body.addClass('done');

		} else {

			body.css('font-size',beforeFontSize);
			body.removeClass('done');

		}
	}
	
	function turnSlide(e) {

		if(body.css('background-color') != '#000000') return;

		var hash = document.location.hash;

		if(!hash.length) return;

		hash = hash.substr(1).split('-');

		var base = hash[0]+'-';
		var slide = parseInt(hash[1]);

		switch (e.which) {
			case 32:
			case 40:
			case 39:
				slide++;
				break;
			case 37:
			case 38:
				slide--;
				break;
			default:
				return;
		}

		if($('#'+ base + slide).length) {
			document.location.hash = '#'+ base + slide;
		} else {
			return;
		}
	}

	$(window).resize(updateView).load(updateView);
	$(document).keydown(turnSlide);
});