var keyState	= [],
	keyUp		= [],
	gameBoard	= [],
	angle		= 0,
	playgroundSide	= 0,
	frameCount		= 0,
	renderContext	= null,
	initialPlaygroundSide = 7,
	playgroundSideIncrement = 2,
	currentView	= 1
	view		= 0
	objectList	= {},
	textureList	= {}
	player		= {angle:0,score:0},
	food		= {level:0}


a=opera.postError
onload = function()
{
	var canvasTag = document.getElementById('renderArea')
	renderContext = canvasTag.getContext('opera-3d')
	renderContext.nearPlane	= 0.1;
	renderContext.farPlane	= 512;
	renderContext.fov		= 90;

	/*
	*	init the keyState functions
	*/
	for( var i=0; i<256; i++ )	keyState[i]=keyUp[i]=0
	window.onkeydown	= function( e ){keyState[ e.keyCode ] = 1}
	window.onkeyup		= function( e ){keyState[ e.keyCode ] = 0; keyUp[ e.keyCode ] = 1}

	initLevel( initialPlaygroundSide-playgroundSideIncrement )
	player.notPlaying++
	updateGame()
}

/*
*	initLevel
*/
function initLevel( newPlaygroundSide )
{
	frameCount		= 0
	playgroundSide	= newPlaygroundSide
	/*
	*	init the textures
	*/

	var	tmpImgQuad		= new Image(),
		tmpImgFour		= new Image()
		tmpImgQuad.src	= "img/quad.png"
		tmpImgFour.src	= "img/4.png"

	textureList.quad	= renderContext.createTexture( tmpImgQuad )
	textureList.four	= renderContext.createTexture( tmpImgFour )


	/*
	*	init basic objects
	*/

	//	playground
	for( var i=0;i<playgroundSide*playgroundSide; i++ )
		gameBoard[i]=0
	objectList.playground =
	{
		texture	:'quad',
		model	:renderContext.create3DModel()
	}
	with( objectList.playground.model )
	{
		addVertex( 0,0,0, 0,0 )
		addVertex( 0,0, playgroundSide*2, playgroundSide,0 )
		addVertex(  playgroundSide*2,0, playgroundSide*2, playgroundSide,playgroundSide )
		addVertex(  playgroundSide*2,0,0, 0,playgroundSide )

		addTriangle( 0, 1, 2 )
		addTriangle( 0, 2, 3 )
	}

	objectList.playgroundWall =
	{
		texture	:'quad',
		model	:renderContext.create3DModel()
	}
	with( objectList.playgroundWall.model )
	{
		addVertex( 0,0,0, 0.5,0 )
		addVertex( 0,0, playgroundSide*2, 0.5,0 )
		addVertex(  playgroundSide*2,0, playgroundSide*2, 0.5,0 )
		addVertex(  playgroundSide*2,0,0, 0.5,0 )

		addVertex( -8,12,-8, 0.5,0.25 )
		addVertex( -8,12,8+playgroundSide*2, 0.5,0.25 )
		addVertex( 8+playgroundSide*2,12,8+playgroundSide*2, 0.5,0.25 )
		addVertex( 8+playgroundSide*2,12,-8, 0.5,0.25 )


		addTriangle( 0, 1, 4 )
		addTriangle( 5, 4, 1 )

		addTriangle( 1, 2, 5 )
		addTriangle( 6, 5, 2 )

		addTriangle( 2, 3, 6 )
		addTriangle( 7, 6, 3 )

		addTriangle( 3, 0, 7 )
		addTriangle( 4, 7, 0 )
	}


	//	body part
	objectList.bodyPart =
	{
		texture	:'four',
		model	:renderContext.create3DModel()
	}
	with( objectList.bodyPart.model )
	{
		addVertex( -.9, .2, .9, .5,0   )
		addVertex(  .9, .2, .9,  1,0   )
		addVertex(   0,1.2, 1.4, .5,.5 )

		addVertex( -.6, .2,-.9, .5,0   )
		addVertex(  .6, .2,-.9,  1,0   )
		addVertex(   0,1.0,-.5, .5,.5 )

		addVertex( -.9, .2, .9,  0,0   )
		addVertex(   0,1.2, 1.4, .5,0   )
		addVertex(   0,1.0,-.5, .5,.5  )
		addVertex( -.6, .2,-.9,  0,.5  )

		addVertex(  .6, .2,-.9,  0,.5  )
		addVertex(  .9, .2, .9,  0,0   )


		addTriangle( 0,1,2 )
		addTriangle( 3,4,5 )
		addTriangle( 6,7,8 )
		addTriangle( 8,9,6 )

		addTriangle(10,7,8 )
		addTriangle( 7,11,10 )
	}

	//	food
	objectList.food =
	{
		texture	:'four',
		model	:renderContext.create3DModel()
	}
	with( objectList.food.model )
	{
		addVertex( -.5,  0,-.5,  1, 0   )
		addVertex(  .5,  0,-.5, .5, 0   )
		addVertex(  .5,  0, .5,  1, 0   )
		addVertex( -.5,  0, .5, .5, 0   )
		addVertex(   0, .5,  0, .5, .5  )
		addVertex(   0,-.5,  0, .5, .5  )

	    addTriangle(  0, 1, 4 )
		addTriangle(  1, 2, 4 )
		addTriangle(  2, 3, 4 )
	    addTriangle(  3, 0, 4 )
	    addTriangle(  0, 1, 5 )
		addTriangle(  1, 2, 5 )
		addTriangle(  2, 3, 5 )
	    addTriangle(  3, 0, 5 )
	}

	//	panelNextLevel
	objectList.panelNextLevel =
	{
		texture	:'four',
		model	:renderContext.create3DModel()
	}
	with( objectList.panelNextLevel.model )
	{
		addVertex( -1, -1, -.1, .05, .95)
		addVertex(  1, -1, -.1, .45, .95)
		addVertex(  1,  1, -.1, .45, .55)
		addVertex( -1,  1, -.1, .05, .55)

		addTriangle( 0,1,2 )
		addTriangle( 0,2,3 )
	}

	//	panelGameOver
	objectList.panelGameOver =
	{
		texture	:'four',
		model	:renderContext.create3DModel()
	}
	with( objectList.panelGameOver.model )
	{
		addVertex( -1, -1,  .1, .55, .95)
		addVertex(  1, -1,  .1, .95, .95)
		addVertex(  1,  1,  .1, .95, .55)
		addVertex( -1,  1,  .1, .55, .55)

		addTriangle( 0,1,2 )
		addTriangle( 0,2,3 )
	}


//*/

	//	init the player
	player		=
	{
		x:playgroundSide&-2,
		y:playgroundSide&-2,
		health:3,
		angle:player.angle,
		ouch:0,
		thurst:2.0,
		maxLength:1,
		positionStack:[],
		notPlaying:0,
		score:playgroundSide>initialPlaygroundSide?player.score:0
	}

	// init food
	food.level = 0
	initFood( 0 )
}


/*
 *	updateGame
 */
function updateGame()
{
	var	rC = renderContext,
		oldPlayerX	= player.x,
		oldPlayerY	= player.y,
		thurst		= 0,
		damping 	=.85,
		epsilon		= .01

	frameCount++
	angle = angle*damping+player.angle*(1-damping)
	currentView = currentView*damping+view*(1-damping)

	if( !player.notPlaying )
	{
		thurst = .25
		player.thurst += thurst
		if( player.thurst>=2.0 )
		{
			var overThurst = player.thurst-2.0
			thurst = 2.0-player.thurst
			player.thurst -= 2.0

			player.x -= thurst*Math.sin(player.angle*Math.PI/2)
			player.y += thurst*Math.cos(player.angle*Math.PI/2)
			//	bang!
			player.x = Math.round( Math.min( playgroundSide*2-2, Math.max( 0, player.x ) ) )&-2
			player.y = Math.round( Math.min( playgroundSide*2-2, Math.max( 0, player.y ) ) )&-2

			player.inGameBoard = Math.floor(player.x/2+player.y/2*playgroundSide)
			if( !player.positionStack[0] || player.inGameBoard!=player.positionStack[0].inGameBoard )
			{
				if( player.positionStack.length>=player.maxLength )
		 			gameBoard[ player.positionStack.pop().inGameBoard ]=0
				player.positionStack.unshift(
					{
						angle	:player.angle,
						x		:Math.floor(player.x),
						y		:Math.floor(player.y),
						inGameBoard :player.inGameBoard

					} )
			}

			if( gameBoard[ player.inGameBoard ] )
				player.ouch = 1.0

			gameBoard[ player.inGameBoard ]=1

			if( !food.level )
				initFood( food.level+1 )

			player.score += player.positionStack.length
			if( player.inGameBoard==food.inGameBoard )
			{
				player.maxLength += food.level
				initFood( food.level+1 )
				if( food.level>playgroundSide )
				{
					player.notPlaying++
					player.score += 100
				}
			}

			thurst = overThurst
			player.angle += (keyUp[39]-keyUp[37])
			keyUp[39]=keyUp[37]=0
		}
		player.x -= thurst*Math.sin(player.angle*Math.PI/2)
		player.y += thurst*Math.cos(player.angle*Math.PI/2)
	}
	else
	{
		player.notPlaying++
	}

	//	clip the player within the playground
	player.x = Math.min( playgroundSide*2-2, Math.max( 0, player.x ) )
	player.y = Math.min( playgroundSide*2-2, Math.max( 0, player.y ) )

	if( thurst!=0 && Math.abs(oldPlayerX-player.x)<epsilon && Math.abs(oldPlayerY-player.y)<epsilon )
		player.ouch = 1.0


	/*
	*	render
	*/
	rC.beginScene()
	rC.save()

		if(keyUp[38])
		{
			view ^= 1
			keyUp[38]=0
		}


		rC.rotateX( 30+60*currentView )
		rC.rotateZ( -(1.0-currentView)*8*Math.sin( (Math.floor(angle)-angle)*Math.PI ) )
		rC.translate( 0,0,-4 )
		rC.rotateY( angle*90 )
		rC.translate( -playgroundSide*2,0,-playgroundSide*2 )
		rC.translate( player.x+1,0,player.y+1 )
		rC.translate( 0,-2.5-27.5*currentView,0 )

		rC.ztest = "lessequal"
		rC.blend = "replace"

		// render the playground
		rC.color = '#6cf'
		rC.texture	= textureList[ objectList.playground.texture ]
		rC.draw3DModel( objectList.playground.model )

	rC.save()
		rC.translate( playgroundSide*2,0,playgroundSide*2 )

		// render the snake

		rC.translate( -1-player.x,0,-1-player.y )

		rC.color = player.health?'#fff':'#444'
		rC.texture	= textureList[ objectList.bodyPart.texture ]

		var currentPosition = {angle:player.angle,x:player.x,y:player.y}
		rC.rotateY( -currentPosition.angle*90 )
		rC.translate( 0,player.health?0:-.15,player.thurst )
		for( var i=0; i<player.positionStack.length; i++ )
		{
			var angleDifference = currentPosition.angle-player.positionStack[i].angle;
			if( 0!=angleDifference )
				rC.rotateY( angleDifference*45 )

			m = i*player.health?Math.abs( .2*Math.cos( (i+frameCount)*Math.PI/4 ) ):0
			rC.translate( 0,m,0 )
			if( !player.health )
				rC.rotateZ( 30*Math.cos(i) )

			z = i?.75:1
			rC.scale( z,z,z )
			rC.draw3DModel( objectList.bodyPart.model )
			z = 1.0/z
			rC.scale( z,z,z )

			if( !player.health )
				rC.rotateZ( -30*Math.cos(i) )
			if( angleDifference )
				rC.rotateY( angleDifference*45 )
			currentPosition = player.positionStack[i]
			rC.translate( 0,-m,2 )
		}
	rC.restore()
	rC.save()

		// render the food
		rC.color = '#f'+(4+Math.round(Math.random()*5))+'0'
		rC.blend = 'replace'
		rC.texture	= textureList[ objectList.food.texture ]
		rC.translate( -1+(playgroundSide-food.x)*2,.75+Math.abs(.5*Math.cos(frameCount*Math.PI/10)),(playgroundSide-food.y)*2-1 )
		rC.rotateY( frameCount*20 )

		rC.draw3DModel( objectList.food.model )
/**/
		rC.texture	= null
		rC.color = '#600'
		rC.blend = 'add'
		rC.draw3DModel( objectList.food.model )
/**/

	rC.restore()
	rC.save()

		// render the playgroundWall
		rC.blend = 'add'
		rC.color = '#6cf'
		rC.texture	= textureList[ objectList.playgroundWall.texture ]
		rC.draw3DModel( objectList.playgroundWall.model )

	rC.restore()
	rC.restore()

	if( player.notPlaying )
	{
		player.notPlaying++

		// panels
		rC.save()
		rC.blend = 'srcalpha'
		rC.ztest = 'none'
		rC.translate( 0,0,-2.5+2*Math.cos(player.notPlaying*Math.PI/64) )
		rC.rotateZ( 20*Math.cos(player.notPlaying*Math.PI/48) )
		rC.rotateY( 20*Math.sin(player.notPlaying*Math.PI/32) )
		rC.rotateX( 40*Math.cos(player.notPlaying*Math.PI/40) )
		if( player.health )
		{
			rC.color = keyState[13]?'#fff':(frameCount&2?'#8f8':'#8fc')
			rC.texture	= textureList[ objectList.panelNextLevel.texture ]
			rC.draw3DModel( objectList.panelNextLevel.model )
		}
		else
		{
			rC.color = keyState[13]?'#fff':(frameCount&1?'#900':'#c00')
			rC.texture	= textureList[ objectList.panelGameOver.texture ]
			rC.draw3DModel( objectList.panelGameOver.model )

		}
		rC.restore()
		if( keyUp[13] )
		{
			rC.endScene()
			keyUp[13]=0
			initLevel( player.health?playgroundSide+playgroundSideIncrement:initialPlaygroundSide )
			updateGame()
			return
		}
	}
	rC.endScene()



	//	red screen of death
	if( !player.notPlaying && player.ouch && player.health)
	{
		player.health = Math.max( 0, player.health-player.ouch )
		if( !player.health )
			player.notPlaying++
	}

//*
	var canvasTag = document.getElementById('renderArea')
	renderContext2d = canvasTag.getContext('2d')
	renderContext2d.save()
	renderContext2d.fillStyle = 'rgba(255,0,0,'+ player.ouch +')'
	renderContext2d.fillRect( 0,0,640,480 )
	renderContext2d.restore()
/**/
	player.ouch = Math.max( 0, player.ouch-.2 )

	var tmp = document.getElementById('yourScore');
	if( tmp.firstChild )
		tmp.removeChild( tmp.firstChild )
	tmp.appendChild( document.createTextNode( 'score: '+ player.score ) )

	if( !keyState[27] )
		setTimeout( updateGame, 20 )
	return
}

function initFood( foodLevel )
{
	food.level = foodLevel
	do
	{
		food.x=Math.floor(Math.random()*playgroundSide)
		food.y=Math.floor(Math.random()*playgroundSide)
		food.inGameBoard = food.x+food.y*playgroundSide
	}
	while( gameBoard[food.inGameBoard]!=0 )
}