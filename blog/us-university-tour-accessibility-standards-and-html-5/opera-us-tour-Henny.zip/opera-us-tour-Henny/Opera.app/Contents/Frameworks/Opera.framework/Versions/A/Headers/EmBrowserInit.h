#ifdef __MWERKS__
#pragma export on
#endif

extern "C" EmBrowserStatus WidgetInitLibrary(EmBrowserInitParameterBlock *initPB);

#ifdef __MWERKS__
#pragma export off
#endif
